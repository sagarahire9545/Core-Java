package wrapper_classes;
public class Ex1 {

	public static void main(String[] args) {
		
		
		}
		
	}


