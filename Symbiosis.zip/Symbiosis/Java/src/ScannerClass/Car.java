package ScannerClass;

import java.util.Scanner;

public class Car {

	

	public static void main(String[] args) {
		String name;
		String colour;
		int No;

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter car details...");

		System.out.println("enter car name:");
		name = sc.next();

		System.out.println("enter car colour:");
		colour = sc.next();

		System.out.println("enter car number:");
		No = sc.nextInt();
		
		System.out.println("car Name:" +name);
		System.out.println("car Colour: "+colour);
		System.out.println("car Number: "+No);


		Car c = new Car();
	
//		System.out.println(c.name);
//		System.out.println(c.colour);
//		System.out.println(c.No);
	}

}
