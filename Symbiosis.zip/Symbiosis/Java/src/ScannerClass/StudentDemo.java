package ScannerClass;
import java.util.Scanner;

public class StudentDemo {

	public static void main(String[] args) {

		int rollno;
		String name,add,mobno;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter student details...");
		
		System.out.println("Enter studen name:");
        name=sc.next();
        
        System.out.println("Enter studen RollNo:");
        rollno=sc.nextInt();
        
        System.out.println("Enter studen address:");
        add=sc.next();
        
        System.out.println("Enter studen MobNo:");
        mobno=sc.next();
        
        System.out.println("The Student details are:");
        System.out.println("Name:"+name+"\nRollNo:"+rollno+"\nAddress:"+add+"\nMobNo:"+mobno);
		
		
	}

}
