package Programs;
import java.util.Scanner;
public class EmpSalary {

	public static void main(String[] args)
	{

		double basic;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter basic salary");
	    basic=sc.nextDouble();
		
		double hra=(45.0/100.0)*basic;
		
		System.out.println("Enter hra:"+hra);
		
		
		double da=(55.0/100.0)*basic;
		System.out.println("Enter da:"+da);

		
		double gs;
		gs=basic+hra+da;
		
		System.out.println("Gross salary:"+gs);
		
		
		
	}

}
