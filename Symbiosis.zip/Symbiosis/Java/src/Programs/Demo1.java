package Programs;



class A {
    int a=10; 
    int b=20;
    
	
	A(){
		
		this.a=a;
		this.b=b;
		System.out.println("parameterized constructor"+a+" "+b);
	}
	public A(int i, int j) {
		// TODO Auto-generated constructor stub
	}
	void add() {
		int x=a+b;
		System.out.println("sum:"+x);
	}
	void mul() {
		int y=a*b;
		System.out.println("mul:"+y);
	}
	 
	
	

}

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
	A a=new A(2,4);
	
	a.add();
	a.mul();
	
	}

}
