package Programs;

import java.util.Scanner;

class Box {
	double height;
	double width;
	double depth;

	Box() {
		System.out.println("Default costructor");
		/*
		 * height = 10; width = 10; depth = 10;
		 */
	}

	 Box(double h, double w, double d) {
		super();
		this.height = h;
		this.width = w;
		this.depth = d;
	}

	double volume() {
		return height * width * depth;
	}

}

public class ConstructorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Box b = new Box(); System.out.println("The box volume: " + b.volume());
		 * 
		 * Box b1 = new Box(); System.out.println("The box volume: " + b1.volume());
		 * 
		 * // using parameterized constructor Box b3 = new Box(20, 20, 20);
		 * System.out.println("The box volume: " + b3.volume());
		 */

		// using scanner class

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter box details...");

		System.out.println("Enter height: ");
		double h = sc.nextDouble();

		System.out.println("Enter width: ");
		double w = sc.nextDouble();

		System.out.println("Enter depth: ");
		double d = sc.nextDouble();

		Box b4 = new Box(h, w, d);
		System.out.println("The volume is: " + b4.volume());
	}

}
