package Programs;

public class SquareRoot {

	public static void main(String[] args) 
	{

		/*
		 * int x=10; double st=Math.sqrt(x); 
		 * System.out.println(st);
		 */
		
		int a=225;
		int b=0;
		
		for(int i=2;i<a;i++)
		{
			if((a%i)==0 && (i*i)==a){
				b=i;
				break;
			}
		}
		System.out.println(+b);
	}

}
