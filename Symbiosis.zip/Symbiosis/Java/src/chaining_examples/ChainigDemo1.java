package chaining_examples;

class Employee {
	int emp_id;
	String name;
	double EmpSalary;
	static String companyName;

	public Employee() {

		System.out.println("Default constructor...");
	}

	public Employee(int emp_id) {
		this();
		System.out.println("1- parametrized constructor...");
	}

	public Employee(int emp_id, String name) {
		this(emp_id);
		System.out.println("2- parametrized constructor...");
	}

	public Employee(int emp_id, String name, double empSalary) {
		this(emp_id, name);
		System.out.println("3- parametrized constructor...");

		this.emp_id = emp_id;
		this.name = name;
		EmpSalary = empSalary;
	}
	static {
		companyName="Infy";
		System.out.println("Static first call");
	}
	
	

}

public class ChainigDemo1 {
	

	public ChainigDemo1() {
		System.out.println("Im main constructor");
	}

	public static void main(String[] args) {

		ChainigDemo1 vm=new ChainigDemo1();
		Employee emp = new Employee(4, "Sagar", 27000);
		
	}

}
