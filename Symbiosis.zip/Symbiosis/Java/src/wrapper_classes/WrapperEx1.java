package wrapper_classes;

public class WrapperEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int y;
		String str="2020";
		
		y=Integer.parseInt(str);
		System.out.println(y);
	}

}
