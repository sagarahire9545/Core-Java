package Methods;

import java.util.Scanner;

class Product {

	int id;
	String name;
	double price;
	static String brand;
	
	static{
		brand="Samsung";
	}

	public Product() {

		
	}

	public Product(int id, String name, double price, String brand) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.brand = brand;
	}

	public void display() {
		System.out.println("Product id: " + id);
		System.out.println("Product Name: " + name);
		System.out.println("Product Price: " + price);
		System.out.println("Product brand: " + brand);

	}

}

public class ProductDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Product details...");

		System.out.println("Enter prouct ID: ");
		int d = sc.nextInt();

		System.out.println("Enter prouct name: ");
		String n = sc.next();
		
		System.out.println("Enter prouct Price: ");
		double p = sc.nextDouble();


		System.out.println("Enter prouct Brand: ");
		String b = sc.next();

		
//		Product pr = new Product(12,"gf",8699,"hjgkh");
		Product pr = new Product(d,n,p,b);
		pr.display();
	}

}
