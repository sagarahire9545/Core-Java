package Methods;

import java.util.Scanner;

class Test {

	int age ;

	void m1() {
		 
		System.out.println("M1 method");
		System.out.println("Age: " + age);
	}

	void m2() {
		System.out.println("M2 method");
		System.out.println("Age: " + age);
	}
}

public class NonStaticMethod {

	public static void main(String[] args) {

		
		Test test = new Test();

		test.m1();
		test.m2();

		// ------------------------

		new Test().m1();
		new Test().m2();

	}

}
