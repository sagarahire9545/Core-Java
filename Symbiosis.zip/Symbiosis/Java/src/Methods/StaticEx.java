package Methods;

class Static {
	
	static int a = 50;
	static int b = 20;
	
	void display() {
		System.out.println("Non-Static method.. "+a);
	}
	
	static void show() {
		
		System.out.println("Static method...."+b);
	}
	Static(){
		System.out.println("Constructor");
	}


}

public class StaticEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Static s=new Static();
		s.display();
		s.show();

	}

}
