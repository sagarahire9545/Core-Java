package Methods;

class A {
	int age = 20;
	static int clgCode = 20201;

	A() {
		System.out.println("Im a Constructor..");
		System.out.println("Age: " + age);
		System.out.println("College code:" + clgCode);
		System.out.println("--------------------");

	}

	void meth1() {
		int num = 10; // local variable
		System.out.println("Meth1...");
		System.out.println("Square: " + (num * num));
		System.out.println("Age: " + age);
		System.out.println("College code:" + clgCode);
		System.out.println("--------------------");
	}

	void meth2() {
		System.out.println("Meth2...");
		// System.out.println("Cube: "+(num*num*num)); undefined variable
		System.out.println("Age: " + age);
		System.out.println("College code:" + clgCode);
		System.out.println("--------------------");

	}

	static void meth3() {
		System.out.println("Meth3...");
//		System.out.println("Square: "+(num*num));
//		System.out.println("Age: "+age);
		System.out.println("College code:" + clgCode);
		System.out.println("--------------------");
		

	}

	static {
		System.out.println("Static block...");
//		System.out.println("Square: "+(num*num));
//		System.out.println("Age: "+age);
		System.out.println("College code:" + clgCode);
		System.out.println("--------------------");

	}
}

public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A.meth3();
		A a = new A();
		a.meth1();
		a.meth2();
		// a.meth3();

	}

}
