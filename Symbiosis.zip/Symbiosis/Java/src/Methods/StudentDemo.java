package Methods;

import java.util.Scanner;

class Student {
	int rollNo;
	String name;
	float marks;

	public Student() {
		rollNo = 04;
		name = "Ajay";
		marks = 82;
		System.out.println("Im a constructor");
	}

// Parameterized constructor
	public Student(int rollNo, String name, float marks) {

		this.rollNo = rollNo;
		this.name = name;
		this.marks = marks;
	}

	public void display() {

		System.out.println("Student rollno: " + rollNo);
		System.out.println("Student Name : " + name);
		System.out.println("Student Marks: " + marks);
	}
}

public class StudentDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter rollno: ");
		int r = sc.nextInt();
		System.out.println("Enter name: ");
		String name = sc.next();
		System.out.println("Enter marks: ");
		int m = sc.nextInt();

		Student st = new Student(r,name,m);
		st.display();

	}

}
