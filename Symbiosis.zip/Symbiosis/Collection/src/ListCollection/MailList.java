package ListCollection;

import java.util.LinkedList;

public class MailList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Address> list=new LinkedList<>();
		list.add(new Address("Yuvraj Singh","Nashik road","Nashik","Maharashtr","423204"));
		list.add(new Address("Suresh raina","Mumbai road","Mumbai","Maharashtra","12345"));
		list.add(new Address("Rohit sharma","mb road","Mumbai","Maharashtr","76576"));

		System.out.println(list);
		
		for(Address add:list) {
			System.out.println(add+"\n");
			
			System.out.println();
		}

	}

}
