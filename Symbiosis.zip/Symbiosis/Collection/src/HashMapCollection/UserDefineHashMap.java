package HashMapCollection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


public class UserDefineHashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<Integer,StudentDemo> sd=new HashMap<>();
		sd.put(1, new StudentDemo("Sagar","Ahire"));
		sd.put(2, new StudentDemo("Anil","Sri"));
		sd.put(3, new StudentDemo("Akshay","Ahire"));
		sd.put(4, new StudentDemo("Jivan","Ohk"));
		
		System.out.println(sd);

		Set<Map.Entry<Integer, StudentDemo>> set=sd.entrySet();
		for(Map.Entry<Integer, StudentDemo> itr:set) {
			System.out.println(set);
		}
	}

}
