package HashMapCollection;

public class StudentDemo {
	
	private String firstname;
	private String lastname;
	public StudentDemo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentDemo(String firstname, String lastname) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
	}
	@Override
	public String toString() {
		return "StudentDemo [firstname= " + firstname + ", lastname= " + lastname + "]";
	}
	
	

}
