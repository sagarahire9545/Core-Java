module Collection {
}