
class Aa {
	void add(int a, int b) throws InterruptedException {
		Thread.sleep(2000);
		System.out.println("Sum: " + (a + b));
	}
}
public class SingleThreaded {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Aa oa = new Aa();
		for (int i = 0; i < 10; i++) {
			oa.add(10, 20);
		}

	}

}
