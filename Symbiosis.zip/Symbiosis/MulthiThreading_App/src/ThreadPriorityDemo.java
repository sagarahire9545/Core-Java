
class Booking implements Runnable{

	@Override
	public void run() {
		
		
		try {
			Thread t=  Thread.currentThread();
			System.out.println(t.getName()+":"+t.getPriority()+":"+t.getState()+":"+t.toString());
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}
	
}

public class ThreadPriorityDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Booking b=new Booking();
		Thread th=new Thread(b);
		th.setName("Sacchin");
		th.setPriority(Thread.MAX_PRIORITY);
		th.start();
		
		Thread th1=new Thread(b);
		th1.setName("Priya");
		th1.setPriority(Thread.MIN_PRIORITY);
		//th1.getState();
		th1.start();
		
		

	}

}
