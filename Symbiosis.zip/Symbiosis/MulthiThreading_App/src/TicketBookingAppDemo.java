import java.util.Scanner;

class Ticket implements Runnable {

	private int avlBreath;
	private int resBreath;

	public Ticket(int avlBreath, int resBreath) {
		super();
		this.avlBreath = avlBreath;
		this.resBreath = resBreath;
	}

	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub

		try {
			System.out.println("Available Breath: " + avlBreath + " Reserve Breath: " +resBreath);
			Thread t = Thread.currentThread();

			if (avlBreath >= resBreath) {
				Thread.sleep(2000);
				System.out.println(resBreath + " Breaths Reserved for: " + t.getName());
				
				avlBreath -= resBreath;
				 System.out.println("Available ticket: "+avlBreath);

			} else {
				System.out.println(t.getName() + "Sorry Breath are not available....!");
			}
			System.out.println("--------------------------------------------------------------------");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

public class TicketBookingAppDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String name[]=new String[5];
		int wantTicket[]=new int[5];
		int avlTicket=15;
		for(int i=0;i<name.length;i++) {
			Thread.sleep(1200);
			System.out.println("Enter your name: ");
			name[i]=sc.next();
			
			System.out.println("How much ticket do you want: ");
			 wantTicket[i]=sc.nextInt();
			
			Ticket ti=new Ticket(avlTicket, wantTicket[i]);
			avlTicket -=wantTicket[i];
			
			
			
			Thread tu=new Thread(ti);
			tu.setName(name[i]);
			tu.start();
		}
		
		
	}

}
