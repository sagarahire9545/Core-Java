
class Train implements Runnable {

	private int avlBreath;
	private int resBreath;

	public Train(int avlBreath, int resBreath) {
		super();
		this.avlBreath = avlBreath;
		this.resBreath = resBreath;
	}

	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub

		try {
			System.out.println("Available Breath: " + avlBreath + " Reserve Breath: " +resBreath);
			Thread t = Thread.currentThread();

			if (avlBreath >= resBreath) {
				Thread.sleep(4000);
				System.out.println(resBreath + " Breaths Reserved for: " + t.getName());
				avlBreath -= resBreath;
			} else {
				System.out.println(t.getName() + "Sorry Breath are not available....!");
			}
			System.out.println("--------------------------------------------------------------------");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

public class IRCTC_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Train train = new Train(6, 5);
		Thread u1 = new Thread(train);
		u1.setName("Sagar");
		u1.setPriority(10);
		u1.start();

		Thread u2 = new Thread(train);
		u2.setName("Abhi");
		u2.setPriority(5);
		u2.start();

		Thread u3 = new Thread(train);
		u3.setName("Sachin");
		u3.setPriority(5);
		u3.start();

	}

}
