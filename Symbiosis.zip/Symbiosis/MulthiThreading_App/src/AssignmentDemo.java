class A implements Runnable{
	private String str;

	@Override
	public synchronized void  run() {
		// TODO Auto-generated method stub
		
		try {
			Thread.currentThread();
			if(str=="AA") {
				Thread.sleep(2000);
				System.out.println(str);
			}else {
				str="BB";
			}
			System.out.println("No input");
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
}
public class AssignmentDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A oa=new A();
		Thread t=new Thread(oa); 
		t.setName("AA");
		t.start();
	}

}
