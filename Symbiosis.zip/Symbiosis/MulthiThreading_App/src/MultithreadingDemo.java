

class B implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(2000);
			System.out.println(10+20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}

public class MultithreadingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B ob=new B();  //main resources
		
		for(int i=0;i<200;i++) {
			Thread th=new Thread(ob);

			th.start();
		}

	}

}
