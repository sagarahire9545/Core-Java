package atm_project;

class Customer extends Thread 
{
	String name;
	ATM a;
	double amount;
	
	
	public Customer(String name, ATM a, double amount) {
		super();
		this.name = name;
		this.a = a;
		this.amount = amount;
	}


	public void useAtm() {
		
		a.chackBalance(name);
		a.withDraw(name, amount);
		
	}
	@Override
	public void run() {
		
		useAtm();
		
	}

}
