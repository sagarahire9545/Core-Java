package atm_project;



class ATM implements AtmDemo{

	@Override
	synchronized public void chackBalance(String name) {
		// TODO Auto-generated method stub
		System.out.print(name+ " Checking");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(" Balance.");
		notify();
		
		
		
	}

	@Override

	synchronized public void withDraw(String name, double amount) {
		// TODO Auto-generated method stub
		
		System.out.println(name +" Withdrawing");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(amount);
		System.out.println("***************Another*****************");
		notify();
	}

	
	
}
