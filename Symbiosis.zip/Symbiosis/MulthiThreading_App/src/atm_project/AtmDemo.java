package atm_project;

interface AtmDemo {
	void chackBalance(String name);
	void withDraw(String name,double amount);
	
}
