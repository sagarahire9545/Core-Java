package atm_project;

import java.util.Scanner;

public class Main_Atm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ATM atm=new ATM();
//		
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter your name: ");
//		String str=sc.next();
//		
//		System.out.println("Enter withdraw money: ");
//		double d=sc.nextDouble();
//		
		
		Customer cu=new Customer("Abhay",atm , 1000d);
		Customer cu1=new Customer("Sejal",atm , 20000d);
		cu.start();
		cu1.start();
//		
//		Customer cu3=new Customer(str,atm , d);
//		cu3.start();

	}

}
