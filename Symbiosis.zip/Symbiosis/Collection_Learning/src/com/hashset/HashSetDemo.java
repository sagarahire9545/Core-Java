package com.hashset;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashSet<Employee> emp=new HashSet<>();
		
		emp.add(new Employee(11, "Akash", 12000d));
		emp.add(new Employee(12, "Salunke", 14000d));
		emp.add(new Employee(13, "Abhay", 16000d));
		emp.add(new Employee(14, "Gayu", 34000d));
		emp.add(new Employee(15, "Prajwal",22000d));
		
		System.out.print(emp);
		
		
		

	}

}
