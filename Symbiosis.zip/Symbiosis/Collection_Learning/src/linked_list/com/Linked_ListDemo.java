package linked_list.com;


import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class Linked_ListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList<Integer> list = new LinkedList<>(); 
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		
		//adding elements at the first and last position
		list.addFirst(1);
		list.addLast(80);
		
		//duplication allow
		list.add(20);
		list.add(30);
		
		//remove 20
		//list.remove(2);
//	
//		for(int x:list) {
//			System.out.println(x);
//		}
//		
//		System.out.println("---------------");
		
//		int last=list.lastIndexOf(list);
//		
//        List lt=list.subList(last, 0);
//        System.out.println(lt);
		
		//Iterator
		
		ListIterator<Integer> itr=list.listIterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		System.out.println("---------------------");
		//Iterator foe descending order
		while (itr.hasPrevious()) {
			System.out.println(itr.previous());
			
			System.out.println("------------------");
			
		Collections.reverse(list);
		System.out.println(list);
			
			
		}
		
	}

}
