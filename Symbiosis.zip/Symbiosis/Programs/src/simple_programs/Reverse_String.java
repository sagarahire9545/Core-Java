package simple_programs;

public class Reverse_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name="abcde";
		
		int len=name.length(); //length=5
		String rev="";
		
		for(int i=len-1;i>=0;i--) {
			rev=rev+name.charAt(i);
		}
		System.out.println(rev);

	}

}
