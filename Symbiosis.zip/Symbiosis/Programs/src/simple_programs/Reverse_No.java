package simple_programs;

public class Reverse_No {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 5432;
		int rem, rev = 0;

		while (n != 0)
		{
			rem = n % 10;
			rev = rev * 10 + rem;
			n = n / 10;
			// System.out.println(rev);

		}
		System.out.println(rev);
	}

}
