package simple_programs;

public class Fibonacci_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int input=10;
		int previous=0,next = 1,result=0;
		
		for(int i=0;i<=input;i++) {
			
			System.out.println(+previous);
			result=previous+next;
			previous=next;
			next=result;
			System.out.println(result);
			
		}
		

	}

}
