package simple_programs;

public class SwappingNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=10;
		int b=20;
		int temp = 0;
		
//		a=a+b;
//		b=a-b;
//		a=a-b;
		
//		a=b;
//		b=temp;
//		temp=b;
		
		a=a^b;
		b=a^b;
		a=a^b;
		
		System.out.println(+a+" "+b);
		

	}

}
