package serializationPrograms;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import javax.tools.FileObject;

public class DeserilizationDemo {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		 File file = new File("E:/Customer.txt");
		 
			/*
			 * FileInputStream fis=new FileInputStream(file);
			 *  ObjectInputStream oos=new ObjectInputStream(fis);
			 * 
			 * Customer cu=(Customer)oos.readObject();
			 *  System.out.println(cu);
			 * 
			 * fis.close(); oos.close();
			 */
		 
		 FileInputStream fis=new FileInputStream(file);
		 ArrayList<Customer> custList=new ArrayList<>();
		 
		 boolean cont=true;
		 while(cont) {
			 ObjectInputStream ois=new ObjectInputStream(fis);
			 Customer cust=(Customer)ois.readObject();
			 
			 if(cust!=null) {
				 custList.add(cust);
			 }
				 else
				 {
					 cont=false;
				 }
			 }
		 }

		 
		 
	}

}
