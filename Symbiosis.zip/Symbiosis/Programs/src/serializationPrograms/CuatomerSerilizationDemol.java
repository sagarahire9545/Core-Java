package serializationPrograms;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class CuatomerSerilizationDemol {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		
		File file=new File("E:/Customer.txt");
		FileOutputStream fos=new FileOutputStream(file);
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		
		//Customer cu=new Customer(101, "Sagar Ahire", "Nashik",9765114956l,500);
		Customer cu=new Customer();
		
		oos.writeObject(cu);
		
		System.out.println("Success...");
		
		fos.close();
		oos.close();
		
		

	}

}
