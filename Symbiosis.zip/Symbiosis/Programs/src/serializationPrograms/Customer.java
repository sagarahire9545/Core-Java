package serializationPrograms;

import java.io.Serializable;

public class Customer implements Serializable {

	private int custId;
	private String name;
	private String add;
	private long mobNo;
	private static float avg = 85.00f;
	private transient int t;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(int custId, String name, String add, long mobNo, int t) {
		super();
		this.custId = custId;
		this.name = name;
		this.add = add;
		this.mobNo = mobNo;
		this.t = 500;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	public long getMobNo() {
		return mobNo;
	}

	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}

	public static float getAvg() {
		return avg;
	}

	public static void setAvg(float avg) {
		Customer.avg = avg;
	}

	public int getT() {
		return t;
	}

	public void setT(int t) {
		this.t = t;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", add=" + add + ", mobNo=" + mobNo + ", t=" + t + "]";
	}

}
