package lambda.com;

@FunctionalInterface
//Interface has a contain only one method its called as @FunctionalInterface
interface My {
	public void display();

}

public class MyLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		My my =()->{System.out.println("Hello nnnmkkj");};
		my.display();
		
		

	}

}
