package lambda.com;

interface Ok {

	int add(int a, int b);
}

public class Parameterzied_Lambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ok ok = (x, y) -> {
			return x + y;

		};
		int r = ok.add(20, 10);
		System.out.println(r);

	}

}
