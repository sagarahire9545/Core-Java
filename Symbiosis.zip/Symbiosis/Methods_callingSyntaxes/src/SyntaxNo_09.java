// Syntax no 9

class Syntax{
	
	Employee m1(Person p) {
		return new Employee();
		
	}
	
	static Employee m2(Person p) {
		return new Employee();
		
	}
}
public class SyntaxNo_09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
              
		Syntax ref=new Syntax();
		Person p=new Person();
		Employee emp=ref.m1(p);
		System.out.println(emp);
		
		Employee emp1=Syntax.m2(p);
		System.out.println(emp1);
	}

}
