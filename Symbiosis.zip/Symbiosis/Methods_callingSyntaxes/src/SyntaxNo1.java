
class A{
	void m1() {
		System.out.println("I am m1");
	}
	static void m2() {
		System.out.println("m2...");
	}
	
}

public class SyntaxNo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A oa=new A();
		oa.m1();
		A.m2();
		
	}

}
