
public class Person {
	

	String name;
	String address;
	
	char gender;
	long mob;
	
	public Person() {
		 name="Sagar";
		 address="Nashik";
		
	}
	public Person(String name, String address, char gender, long mob) {
		super();
		this.name = name;
		this.address = address;
		this.gender = gender;
		this.mob = mob;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", address=" + address + ", gender=" + gender + ", mob=" + mob + "]";
	}
	

}
