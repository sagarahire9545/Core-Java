
class AB{
	void m1(Person p) {
		System.out.println("I am m1:");
	}
	static void m2(Person p) {
		System.out.println("I am m2:");
	}
}

public class SyntaxNo03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AB ab=new AB();
		ab.m1(new Person());
		
		Person p1;
		AB.m2(p1=new Person());
		
	}

}
