
public class Employee {

	String name;
	String add;
	double mob;
	
	public Employee() {
		name="Sagar";
		add="Nashik";
		mob=97579769l;
	}
	public Employee(String name, String add, double mob) {
		super();
		this.name = name;
		this.add = add;
		this.mob = mob;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", add=" + add + ", mob=" + mob + "]";
	}
	
}
