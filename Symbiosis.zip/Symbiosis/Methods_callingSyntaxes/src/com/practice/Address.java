package com.practice;

public class Address {

	int adId;
	String city;
	String country;
	String street;

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address(int adId, String city, String country, String street) {
		super();
		this.adId = adId;
		this.city = city;
		this.country = country;
		this.street = street;
	}

	@Override
	public String toString() {
		return "Address [adId=" + adId + ", city=" + city + ", country=" + country + ", street=" + street + "]";
	}

}
