package com.practice;

public class Syntax_07 {

	Address m1() {

		return new Address(1,"nashik","India","Satana-road");
	}

	static Address m2() {

		return new Address();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Syntax_07 s=new Syntax_07();
		
		//calling non-static method
		
		Address ad=s.m1();
		Address ad2=s.m2();
		System.out.println(ad);
		
		//static method calling
		
		Address ad1=Syntax_07.m2();
		System.out.println(ad1);
		
	}

}
