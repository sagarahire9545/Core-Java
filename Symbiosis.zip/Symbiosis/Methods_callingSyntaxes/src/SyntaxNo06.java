import java.util.Random;

class A6 {

	int openAccount(Person p) {

		System.out.println("Account holder details:" + p);
		Random rad = new Random();

		if (p != null)
			return rad.nextInt(1000000000);
		else
			return 0;

	}

	static boolean m2(String an) {
		if (an.equals("Male"))
			return true;
		else
			return false;
	}
}

public class SyntaxNo06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A6 oa = new A6();
		Person p = new Person("Sagar", "Nashik", 'm', 9527893687l);
		int accountNumber = oa.openAccount(p);
	
		
		System.out.println("Congrats your account created succssfully....!"+accountNumber);
		
		boolean b = A6.m2("Male");
		System.out.println(b);
	}

}
