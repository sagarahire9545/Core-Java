// without accepting any i/p value and returning object
// its also called factory method

class Syntax7 {

	Person m1() {

		return new Person();

	}

	static Person m2() {

		return new Person();

	}

}

public class SyntaxNo_07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Syntax7 s1 = new Syntax7();
		Person p = s1.m1();
		System.out.println(p);

		Person p1 = Syntax7.m2();
		System.out.println(p1);
	}

}
