
class Student {
	int m1() {

		return 10;
	}

	static float m2() {
		return 20.20f;
	}
}

public class Syntax_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student s1 = new Student();
		int a = s1.m1();
		System.out.println(a);
		float f = Student.m2();
		System.out.println(f);
	}

}
