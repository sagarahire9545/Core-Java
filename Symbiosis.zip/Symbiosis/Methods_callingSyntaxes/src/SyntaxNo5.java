
class B1
{
char m1(int a) {
		char grade;
		if(a>=50 && a<=60)
			grade ='C';
		else if(a>60&&a<=70)
			grade ='B';
		else
			grade='A';
		return grade;
	}
	
	static long m2(boolean b) {
		if(b)
			return 1000000;
		else
			return -50000;
		
		
	}
}


public class SyntaxNo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		B1 ob = new B1();
		char g=ob.m1(65);
		System.out.println(g);
		
		long prize=B1.m2(false);
		System.out.println(prize);
	}

}
