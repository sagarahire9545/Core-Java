class B{
	void m1(int a ) {
		System.out.println("I am m1");
	}
	static void m2(boolean b) {
		System.out.println("m2...");
	}
	
}

public class SyntaxNo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		B oa=new B();
		oa.m1(10);
		B.m2(true);
		
	}

}

