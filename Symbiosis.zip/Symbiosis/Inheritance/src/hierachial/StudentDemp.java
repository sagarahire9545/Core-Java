package hierachial;

import java.util.Scanner;

class StudentD {
	int rollNo;
	String name;
	double m1, m2, m3;
	double marks;

	public StudentD(int rollNo, String name, double m1, double m2, double m3) {

		this.rollNo = rollNo;
		this.name = name;
		this.m1 = m1;
		this.m2 = m2;
		this.m3 = m3;
	}

}

class Insem extends StudentD {

	public Insem(int rollNo, String name, double m1, double m2, double m3) {
		super(rollNo, name, m1, m2, m3);

	}

	double result() {
		double total = (m1 + m2 + m3) + 10;
		double avg = total / 3;
		System.out.println("Student Insem averages  marks: " + avg);
		return avg;
	}

}

class Endsem extends StudentD {

	public Endsem(int rollNo, String name, double m1, double m2, double m3) {
		super(rollNo, name, m1, m2, m3);

	}

	double result() {
		double total = (m1 + m2 + m3);
		double avg = total / 3;
		System.out.println("Student Endsem averages  marks: " + avg);
		return avg;
	}

}

public class StudentDemp {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter student details...");

		System.out.println("RollNo: ");
		int rno = sc.nextInt();

		System.out.println("Name: ");
		String name = sc.next();

		System.out.println("M1: ");
		double m1 = sc.nextDouble();

		System.out.println("M2: ");
		double m2 = sc.nextDouble();

		System.out.println("M3: ");
		double m3 = sc.nextDouble();

		Insem in = new Insem(rno, name, m1, m2, m3);
		in.result();

		System.out.println("------------------");
		Endsem ed = new Endsem(rno, name, m1, m2, m3);
		ed.result();

	}
}
