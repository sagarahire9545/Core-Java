package learning_inheritance;

public class Box {
	
	double width;
	double height;
	double depth;
	public Box() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Box(double w, double h, double d) {
		super();
		this.width = w;
		this.height = h;
		this.depth = d;
	}
	
	Box(double len){
		width=height=depth=len;
	}
	double volume() {
		return width*height*depth;
	}
	
}

class BoxWidth extends Box{
	
	double width;
	
	public BoxWidth(double w, double h, double d,double m) {
		
		super(w,h,d);
		this.width = w;
		this.height = h;
		this.depth = d;
		this.width=m;
	}

	
	
}