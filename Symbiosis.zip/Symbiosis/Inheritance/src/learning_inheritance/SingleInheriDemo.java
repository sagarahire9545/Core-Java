package learning_inheritance;

class A
{
	public void methodA()
	{
		System.out.println("PARENT CLASS");
	}


}

class B extends A
{
	@Override
	public void methodA()
	{
		System.out.println("Ovveride methodA");
	}
	public void methodB()
	{
		System.out.println("CHILD CLASS");
	}
}

class C extends B
{
	@Override
	public void methodA()
	{
		System.out.println("methA");
	}
	@Override
	public void methodB()
	{
		System.out.println("methB");
	}
	public void methodC()
	{
		System.out.println("methC");
	}
}




public class SingleInheriDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * B a=new B(); a.methodA(); a.methodB();
		 */
		
		C c=new C();
		c.methodA();
		c.methodB();
		c.methodC();
		
	}

}
