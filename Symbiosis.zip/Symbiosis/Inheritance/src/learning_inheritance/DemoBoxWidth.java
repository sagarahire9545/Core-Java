package learning_inheritance;

public class DemoBoxWidth {

	public static void main(String[] args) {
		
		//SSuper class
		Box box=new Box(10,10,10);
		System.out.println("Box volume: "+box.volume());
		
		Box box1=new Box(10);
		System.out.println("Box volume: "+box1.volume());
		
		//sub class
		BoxWidth bw=new BoxWidth(10, 20, 15, 34.3);
		double vol;
		
		vol=bw.volume();
		System.out.println("The volume box: "+vol);
		System.out.println("Width of box is: "+bw.width);
		
		
		
	}
}
