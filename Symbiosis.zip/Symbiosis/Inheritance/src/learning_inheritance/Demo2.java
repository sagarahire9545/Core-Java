package learning_inheritance;

class Parent{
	
	void m1() {
		System.out.println("M1 method.....");
	}
}
class Childc extends Parent{
	
	void m2() {
		System.out.println("M2 method.....");
	}
}


public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//using super class
		Parent oa=new Parent();
		oa.m1();
		System.out.println(oa.toString());
		
		System.out.println("*************************");
		//using child class
		Childc ob=new Childc();
		ob.m1();
		ob.m2();
		System.out.println(ob.toString());
		
		System.out.println("*******************");
		Object o=new Object();
		System.out.println(o.toString());
		
		
	}

}
