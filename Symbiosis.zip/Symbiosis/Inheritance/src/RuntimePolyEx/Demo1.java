package RuntimePolyEx;

class A {

	void diplay() {
		System.out.println("A class");
	}
	
	void m1() {
		System.out.println("m1.....");
	}
}

class B extends A {
	void diplay() {
		System.out.println("B class");
	}
	void m2() {
		System.out.println("m2.....");
	}
}

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		B b = new B();
		b.diplay();
		b.m1();
		b.m2();

		// *********Dynamic Method Dispatch****** i.e run poly
		A a = new B();
		a.diplay();
		a.m1();
		
		

		Object ob = new Object();
		ob.toString();
	}

}
