package hotel.com;

import java.util.ArrayList;
import java.util.List;

class Hotel {

	String name;
	List<String> menu;

	public Hotel(String name) {
		this.name = name;
		this.menu = new ArrayList<>();
	}
	

	public void addMenuItem(String item) {
		menu.add(item);
	}

	public String getName() {
		return name;
	}

	public List<String> getMenu() {
		return menu;
	}

}
