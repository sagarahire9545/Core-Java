package hotel.com;

import java.util.Scanner;

class addHotelDemo {
	
	  static void  addHotel() {
		Scanner sc=new Scanner(System.in);

		System.out.println("Please enter the name of the hotel:");
	    String name = sc.next();

	    Hotel hotel = new Hotel(name);
//        hotel.add(name);
	    
   
	    System.out.println("Hotel added successfully!");
		

	}

}
