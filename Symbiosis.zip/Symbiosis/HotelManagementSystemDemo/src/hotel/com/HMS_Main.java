package hotel.com;

import java.util.Scanner;

public class HMS_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		    System.out.println("Welcome to the Hotel Management System!");

		   
		   
		    while (true) {
		      System.out.println("Please select a login:");
		      System.out.println("1. Admin");
		      System.out.println("2. User");
		      System.out.println("3. Exit");

		     
			int choice = sc.nextInt();

		      if (choice == 1) {
		      AdminLogin.adminLogin();
		      } else if (choice == 2) {
		       UserLogin.userLogin();
		      } else if (choice == 3) {
		        break;
		      } else {
		        System.out.println("Invalid choice!");
		      }
		    }
		  }



	}


