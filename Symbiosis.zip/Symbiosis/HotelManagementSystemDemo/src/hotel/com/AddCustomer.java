package hotel.com;

import java.util.Scanner;

public class AddCustomer {

	static Scanner sc=new Scanner(System.in);
	
	static void addCustomer() {
	    System.out.println("Please enter the customer ID:");
	    int id = sc.nextInt();

	    System.out.println("Please enter the customer name:");
	    String name = sc.next();

	    Customer customer = new Customer(id, name);

	    System.out.println("Customer id: "+id);
	    System.out.println("Customer name: "+name);	    
	    System.out.println("Customer added successfully!");
	}
}
