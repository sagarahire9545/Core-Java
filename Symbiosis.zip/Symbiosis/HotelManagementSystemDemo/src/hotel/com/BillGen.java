package hotel.com;

public class BillGen {

	public static void billGenerate() {
		// TODO Auto-generated method stub

		AddCustomer addC = new AddCustomer();
		addC.addCustomer();

		System.out.println("Your total bill: ");
		System.out.println(Menu.totalBill);

		
	}

}
