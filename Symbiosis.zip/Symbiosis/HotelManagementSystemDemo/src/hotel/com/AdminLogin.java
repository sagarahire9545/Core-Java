package hotel.com;

import java.util.Scanner;

public class AdminLogin {

	static void adminLogin() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter the admin password:");
		String password = sc.next();

		if (!password.equals("sagar")) {
			System.out.println("Incorrect password!");
			return;
		}

		while (true) {
			System.out.println("Please select an option:");
			System.out.println("1. Add a new hotel");
			System.out.println("2. Add a new customer");
			System.out.println("3. Add a new menu item");
			System.out.println("4. Genarate Bill");
			System.out.println("5. Exit");

			int choice = sc.nextInt();

			if (choice == 1) {
				addHotelDemo.addHotel();
				
			} else if (choice == 2) {
				AddCustomer.addCustomer();
			} else if (choice == 3) {
				Menu.addMenu();
			} else if (choice == 4) {
			    BillGen.billGenerate();
			} 
			
			else if (choice == 4) {
				break;
			} else {
				System.out.println("Invalid choice!");
			}
		}
	}


}
