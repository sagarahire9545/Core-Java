package hotel.com;

import java.util.Scanner;

public class Menu {

	static double totalBill = 0;

	public static void addMenu() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Select an option:");
		System.out.println("1. Veg");
		System.out.println("2. Non-veg");

		int menuChoice = sc.nextInt();

		switch (menuChoice) {
		case 1:
			System.out.println("Select a dish:");
			System.out.println("1. Paneer tikks - 200rs");
			System.out.println("2. Garlic Naan - 50rs");
			System.out.println("1. Jira rice - 100rs");

			int vegCh = sc.nextInt();
			switch (vegCh) {
			case 1:
				totalBill += 200;
				break;

			case 2:
				totalBill += 50;
				break;

			case 3:
				totalBill += 100;
				break;

			}

		case 2:
			System.out.println("Select a dish:");
			System.out.println("1. Chicken Tikka - 300rs");
			System.out.println("2. Garlic Naan - 50rs");
			System.out.println("1. Jira rice - 100rs");

			int vegCh1 = sc.nextInt();
			switch (vegCh1) {
			case 1:
				totalBill += 200;
				break;

			case 2:
				totalBill += 50;
				break;

			case 3:
				totalBill += 100;
				break;

			default:
				System.out.println("Invalid input...");
				break;
			}
			break;
		}
	}
}