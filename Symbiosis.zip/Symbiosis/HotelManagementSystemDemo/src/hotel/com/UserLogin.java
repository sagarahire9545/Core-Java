package hotel.com;

import java.util.List;
import java.util.Scanner;

class UserLogin {

	static void userLogin() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter your customer ID:");
		int id = sc.nextInt();

		Customer customer = findCustomerById(id);

		if (customer == null) {
			System.out.println("Invalid customer ID!");
			return;
		}

		System.out.println("Welcome, " + customer.getName() + "!");

		Hotel hotel = selectHotel();

		if (hotel == null) {
			return;
		}

		List<String> items = selectItems(hotel);

		if (items == null) {
			return;
		}

	}

}
