import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Assignment {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		
		File file=new File("E:\\abc/");
		System.out.println(file.getAbsolutePath());
		System.out.println(file.toURI());
		System.out.println(file.getName());
		//System.out.println(file.length());
		
		
		File[] arr=file.listFiles();
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
			String[] s=arr[i].getName().split(".",3);
			System.out.println(s[1]);
		}
		
		

		
	}

}
