import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class AssignmentNo2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileWriter fw=new FileWriter("E:/Text.txt");
		FileWriter fw1=new FileWriter("E:/Java.txt");
		FileWriter fw2=new FileWriter("E:/Class.txt");


		File file=new File("E:\\abc/");
		File[] arr=file.listFiles();
	//	StringBuffer sb=new StringBuffer();
		
		for(File f:arr) {
			System.out.println(f.getName());
			String str=f.getName().replace(".", ". ");
			System.out.println(str);
			String[] s=str.split(". ");
			
			if(s[1].equals("txt"))
			 fw.write(s[0]+"\n");
			 
			 else if(s[1].equals("java"))
				 fw1.write(s[0]+"\n");
			 else
				 fw2.write(s[0]+"\n");
		
		}
		fw.close();
		fw1.close();
		fw2.close();
		

	}

}
