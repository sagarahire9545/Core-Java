import java.io.File;
import java.io.FileWriter;

public class FileWriterDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileWriter fw=null;
		try {
			File file=new File("E:/myFile.txt");
			 fw=new FileWriter(file, true);
			fw.write("\n You have been invited for batch J22....");
			System.out.println("Success..");
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			try {
			fw.close();
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}

	}

}
