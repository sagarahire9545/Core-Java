import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		File file = new File("E:/myFile.txt");
		FileReader fr = new FileReader(file);
		int d;

		while ((d = fr.read()) != -1) {
			System.out.print((char) d);
		}
		fr.close();
	}

}
