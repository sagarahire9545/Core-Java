import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopypateDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		FileInputStream fis=new FileInputStream("C:\\Users\\SAGAR AHIRE\\Desktop\\Alone.jpg");
		FileOutputStream fos=new FileOutputStream("E:/Alone.jpg.");
		
		int d;
		while((d=fis.read())!=-1) {
			System.out.print((char)d);
			fos.write((char)d);
		}
		fis.close();
		fos.close();
		System.out.println("Success..");
	}

}
