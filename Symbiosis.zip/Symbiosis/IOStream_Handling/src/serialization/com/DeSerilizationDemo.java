package serialization.com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeSerilizationDemo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		File file=new File("E:/EmployeeData.txt");
		
	FileInputStream fis=new FileInputStream(file);
	ObjectInputStream ois=new ObjectInputStream(fis);

	Object o=ois.readObject();
	Employee emp=(Employee)o;
	System.out.println("Emp id: "+emp.getEmpId());
	System.out.println("Emp Name: "+emp.getEmpName());
	System.out.println("Emp Mobile: "+emp.getMobNo());
	System.out.println("Emp Address: "+emp.getAddress());
	
	}

}
