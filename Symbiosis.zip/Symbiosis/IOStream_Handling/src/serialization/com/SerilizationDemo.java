package serialization.com;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerilizationDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		File file = new File("E:/EmployeeData.txt");

		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);

		Employee emp = new Employee();
		emp.setEmpId(101);
		emp.setEmpName("Sagar Ahire");
		emp.setAddress("Nashik");
		emp.setMobNo(9765114967l);
		oos.writeObject(emp);
		System.out.println("Success...");
		fos.close();
		oos.close();

	}

}
