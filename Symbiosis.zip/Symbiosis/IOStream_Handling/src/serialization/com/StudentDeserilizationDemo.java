package serialization.com;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class StudentDeserilizationDemo {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub

		File file=new File("E:/StudentData.txt");
		
		FileInputStream fis=new FileInputStream(file);
		ObjectInputStream ois=new ObjectInputStream(fis);

		Object o=ois.readObject();
		Student st=(Student)o;
	
		
		//System.out.println("Name: "+st.getName());
		System.out.println(""+st.toString());
	}

}
