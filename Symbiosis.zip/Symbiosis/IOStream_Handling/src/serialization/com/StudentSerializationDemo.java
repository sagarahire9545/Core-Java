package serialization.com;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class StudentSerializationDemo  {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		File file=new File("E:/StudentData.txt");
		
		FileOutputStream fos=new FileOutputStream(file);
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		
		Student st=new Student();
		st.setName("Sagar Ahire");
		st.setRollNo(12);
		st.setAddress("Nashik");
		st.setMobNo(9765114956l);
	
		
		oos.writeObject(st);
		System.out.println("Success...");
		
		fos.close();
		oos.close();

	}

}
