/*
 * Date :13/03/2023
 * @Sagar Ahire
 */
public interface ATM {
	
	void deposite();
	void withdraw();
	void chack_balance();
	void ministatement();

}
