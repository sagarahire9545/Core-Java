
public class ATM_Methods implements ATM {

	double balance;
	double withdrawal;
	double deposite;
	public void deposite() {
		// TODO Auto-generated method stub
		balance=balance+deposite;
		System.out.println("Money deposited.....!");
	}

	@Override
	public void withdraw() {
		
		// TODO Auto-generated method stub
		if(balance>=withdrawal)
		{
			balance=balance-withdrawal;
			System.out.println("Please collect your money..!");
			
		}else
		{
			System.out.println("Insufficient balance..!");
		}
	}

	@Override
	public void ministatement() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void chack_balance() {
		// TODO Auto-generated method stub
		
	}


}
