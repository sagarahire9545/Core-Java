import java.util.Scanner;

public class ATM_Service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		String choice = " ",conti;
		ATM_User user=new ATM_User();
		
		do {
			System.out.println("Welcome to Badoda ATM Serrvice");
			System.out.println("1. Deposite Money");
			System.out.println("2. Withdraw Money");
			System.out.println("3. Check Money");

			System.out.println("4. Ministatement for account.");
			System.out.println("5. Exit");

			System.out.println("-------------------------------------");
			System.out.println("Enter your choice: ");
		    conti=sc.next();
			

			switch(choice) {
			
			case "Deposite":
				System.out.println("Enter money to be withdraw.");
				user.getOperation(choice);
				
				break;
			case "WithDraw":
				System.out.println("Enter money to be withdraw.");
				user.getOperation(choice);
				break;
				
			case "Check money":
				System.out.println("Enter money to be withdraw.");
				user.getOperation(choice);
				break;
				
			case "MiniStatement":
				System.out.println("Enter money to be withdraw.");
				user.getOperation(choice);
				break;
				
			case "Exit":
				System.out.println("Enter money to be withdraw.");
				user.getOperation(choice);
				break;
			default:
				System.out.println("Invalid...");
			}
			System.out.println("Do you want to continue......(y/Y)");
			conti=sc.next();
		} while (conti.equalsIgnoreCase("y"));
		System.out.println("Thank you visit again...!");
		
	}

}
