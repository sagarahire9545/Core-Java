
public class ATM_User {


	public void getOperation(String choice) {
		// TODO Auto-generated method stub

		try {
			Class cl=Class.forName(choice);
			
			Object o=cl.newInstance();
			ATM atm=(ATM)o;
			atm.deposite();
			atm.withdraw();
			atm.ministatement();
			atm.chack_balance();
			
		}catch(Exception e) {
			System.out.println(e);
		}
	}


	

	
	
}
