
abstract class SayHello {
	abstract void hello();
}

interface MyInter {
	void myAdd();
}

public class AnonymousClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SayHello sl = new SayHello() {

			@Override
			void hello() {
				// TODO Auto-generated method stub
				System.out.println("Hello friends...");

			}

		};
		MyInter mi = new MyInter() {

			@Override
			public void myAdd() {
				// TODO Auto-generated method stub
				System.out.println("Interface .................");

			}
		};

		sl.hello();
		mi.myAdd();

	}

}
