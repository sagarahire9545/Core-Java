
class OuterClass {
	void m1() {
		System.out.println("i am m1");
	}

	class InnerClass {

		void m2() {
			System.out.println("I am m2");
		}

		void m3() {
			m1();
		}
	}

	// Static class
	static class StaticInnerClass {
		void m5() {
			System.out.println("I am m5");
		}

		static void m6() {
			System.out.println("I am m6");
		}
	}

	void m4() {
		new InnerClass().m2();
	}

}

public class InnerClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OuterClass oc = new OuterClass();
		OuterClass.InnerClass oic = oc.new InnerClass();
		OuterClass.StaticInnerClass osic = new OuterClass.StaticInnerClass();
		osic.m5();
		osic.m6();

		oic.m2();
		// oic.m3();
		oc.m1();
		// oc.m4();

	}

}
