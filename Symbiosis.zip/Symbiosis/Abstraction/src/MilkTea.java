
public class MilkTea implements Tea {

	@Override
	public void making() {
		// TODO Auto-generated method stub
		System.out.println("MilTea making process");
		System.out.println("1. Take some milk");
		System.out.println("2. Take some Tea powder");
		System.out.println("3. Take some Sugar");
		System.out.println("4. start your gas and wait 5 to 7 mnt");
		System.out.println("milk tea is ready..");

	}

	@Override
	public void benifits() {
		// TODO Auto-generated method stub

		System.out.println("Good to refresh your mood..");
	}

}
