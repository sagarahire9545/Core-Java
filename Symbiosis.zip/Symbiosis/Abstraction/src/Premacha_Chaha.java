import java.util.Scanner;
//Client class create in the year 2020
public class Premacha_Chaha {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		String choice, conti = " ";
		RamLal ram=new RamLal();
		do {
			System.out.println("Welcome to Premacha Chaha");
			System.out.println("1.MilkTea");
			System.out.println("2.Cofee");
			System.out.println("--------------------------------------");
			System.out.println("Enter your choice: ");
			choice = sc.next();

			switch (choice) {
			case "MilkTea":
				ram.getOrder(choice);
				break;
			case "Cofee":
				ram.getOrder(choice);

				break;
			default:
				System.out.println("Invaalid input please check menu card..");
			}
			System.out.println("Do you want to continue......(y/Y)");
			conti=sc.next();
		} while (conti.equalsIgnoreCase("y"));
		System.out.println("Thank you visit again...!");
	}

}
