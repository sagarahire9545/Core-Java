
public class Cofee implements Tea {

	@Override
	public void making() {
		// TODO Auto-generated method stub
		System.out.println("Cofee making process");
		System.out.println("1. Take some milk");
		System.out.println("2. Take some cofee powder");
		System.out.println("3. Take some Sugar");
		System.out.println("4. start your gas and wait 5 to 7 mnt");
		System.out.println("Cofee tea is ready..");
	}
		
	

	@Override
	public void benifits() {
		// TODO Auto-generated method stub
		System.out.println("Increase your love");
		
	}

	

}
