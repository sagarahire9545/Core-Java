/*
 * Project name:Rea Making application
 * Development Start Date:02/02/2020
 * Developer Name:Raj Kolhe sir
 * Org. Name: Symbiosis Digital Academy
 *
 * 
 * 
 */
public interface Tea {

	void making();
	void benifits();
}
