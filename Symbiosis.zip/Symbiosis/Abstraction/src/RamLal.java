//Container 
public class RamLal {

	public void getOrder(String choice) {
		// TODO Auto-generated method stub
		try
		{
			Class cl=Class.forName(choice);
			Object o=cl.newInstance();//upcasting
			Tea tea=(Tea)o;//down casting
			tea.making();
			tea.benifits();
			
			
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	
} 
