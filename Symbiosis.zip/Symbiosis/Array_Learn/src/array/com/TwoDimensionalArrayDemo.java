package array.com;

import java.util.Scanner;

public class TwoDimensionalArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		int arr[][] = {{1,2,3},{2,3,4},{3,5,6}};
		int arr1[][]= {{8,5,9},{2,3,5},{3,5,8}};

		int sum[][] = new int[3][3];

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr1.length; j++) {

				sum[i][j] = arr[i][j] + arr[i][j];
				System.out.print(sum[i][j] + " ");
			}
			System.out.println();// new line
		}
	}

}
