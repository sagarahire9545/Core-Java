package array.com;

import java.util.Scanner;

public class ArrayDemo {

	public static void main(String[] args) {
		
		//5 elements storing in array
		int arr[]=new int[5];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<5;i++) {
		System.out.println("Enter a: "+(i+1)+" number");
		arr[i]=sc.nextInt();
		}
		
		//normal loop
//		for(int i=0;i<arr.length;i++) {
//			System.out.print(" "+arr[i]+" ");
//		}
		
		//enhanced (for-each loop)loop
		for(int x:arr) {
			System.out.print(x);;
		}
		

	}

}
