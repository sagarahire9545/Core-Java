package array.com;



public class FactWithoutUsingLoop {

	public static void main(String[] args) {
		
		int fact=1;
		int n=14;
		for(int i=n;i>=1;i--) {
			 fact = fact*i;
			 
		}
		System.out.println("The factorial values is: "+fact);
	}

}
