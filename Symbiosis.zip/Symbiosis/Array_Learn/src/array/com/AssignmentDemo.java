package array.com;

import java.util.Scanner;

public class AssignmentDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);

		int[] arr= {10,20,30,40,50,60,70,80};
		System.out.println("Enter the number: ");
		int x=sc.nextInt();
		
		for(int i=0;i<arr.length;i++) {
			
			if(arr[i]==x) {
				
				System.out.println("Number is a present in array..");
				break;
			}
			else {
				System.out.println("Number is not available.....");
				break;
			}
		}

	}

}
