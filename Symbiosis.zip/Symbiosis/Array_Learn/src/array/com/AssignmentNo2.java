package array.com;

public class AssignmentNo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {7,20,21,28,35,60,70,80};
		
		for(int i=0;i<arr.length;i++) {
			
			if((arr[i]%7)==0) {
				System.out.println("The number is dividing by 7");
				
			}else {
				System.out.println("The number is not dividing by 7");
			}
		}

	}

}
