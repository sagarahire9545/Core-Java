package assignment_problems;

class Library{
	
	
}

public class LibraryDemo {

	public static void main(String[] args) {
		

	}

}
