package com.app;

public class SingleTryMultipleCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			int a = Integer.parseInt(args[0]);
			int b = Integer.parseInt(args[1]);

			System.out.println(a / a);
		} catch (NumberFormatException e) {
			// to print msg
			String msg = e.getMessage();
			System.err.println(msg);

			// to print class+msg
			String exDetails = e.toString();
			System.err.println(exDetails);

			// to print exception class+msg+line number
			e.printStackTrace();

		} catch (ArrayIndexOutOfBoundsException ae) {
			ae.printStackTrace();
		} catch (ArithmeticException ar) {
			ar.printStackTrace();
		}
	}

}
