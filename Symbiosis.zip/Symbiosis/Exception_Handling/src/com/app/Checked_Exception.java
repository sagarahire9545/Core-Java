package com.app;

import java.lang.reflect.Method;

public class Checked_Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			
			//Loading the all methods of Scanner Class
			Class cl = Class.forName("java.util.Scanner");
			Method[] ms = cl.getDeclaredMethods();
			for (int j = 0; j < ms.length; j++) {
				System.out.println(ms[j]);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
