package com.app;

import java.util.Scanner;

class Bank {
	double balance;

	public Bank() {
		super();
		this.balance = 10000;
	}

	public void deposite(double amountDeposite) {
		balance = balance + amountDeposite;
		System.out.println("You just deposited: " + amountDeposite);
		System.out.println("Total amount: "+balance);
	}

	public void withdraw(double amountWithdraw)throws PaymentException {
		if (balance > amountWithdraw) {
			balance = balance - amountWithdraw;
			System.out.println("You just withdraw: " + amountWithdraw);
			System.out.println("Total amount: "+balance);
		} else {
			//System.out.println("Insufficient balance...");
			throw new PaymentException();
		}
	}

}

public class BankDemo {

	public static void main(String[] args) throws PaymentException{
		// TODO Auto-generated method stub

		Bank bank = new Bank();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Welcome to Bank Of Baroda...");

		System.out.println("-----------------------");
		System.out.println("Enter the deposite amount: ");
		double de = sc.nextDouble();

		bank.deposite(de);

		System.out.println("Enter the withdraw amount: ");
		double wi = sc.nextDouble();

		bank.withdraw(wi);

	}

}
