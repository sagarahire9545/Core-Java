package com.app;

public class PaymentException extends Exception {

	public String toString() {
		return("Unsufficeint Balance");
	}
	
}
