package exceptin_1;

import java.io.IOException;

class A
{
	void m1()throws RuntimeException {
		System.out.println("I am m1 of A");
	}
}
class B extends A{
	//child level can not be use checked excpetion
	//only unchecked exception
	void m1() throws ArrayIndexOutOfBoundsException {
		System.out.println("I am m1 of B");
	}
}
public class ExceptionHandlingWithMethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A oa = new B();
		oa.m1();
	}

}
