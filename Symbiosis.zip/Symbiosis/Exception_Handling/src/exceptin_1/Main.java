package exceptin_1;

class MyException extends Exception {
	public MyException(String s) {
		super(s);
	}

}

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			throw new MyException("Symbiosis..");
		} catch (MyException ex) {
			System.err.println("Caught");
		}
	}

}
