
public class CountWhiteSpaceDemo {

	public static void main(String[] args) {

		String str = ("A simple paragraph is the first element taught in writing."
				+ " It is an independent entity, without any connection to any other topic, thought or idea."
				+ " It exists on its own.");

		// Count white Spaces
		int Space = 0;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);

			if (ch == ' ') {
				Space++;
			}
		}
		System.out.println(Space);
	}
}