
public class StringDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "220344221048_Ravina Chandrashekhar Raut.pdf";
		System.out.println(str);

		String st[] = str.split("_");
		System.out.println(st[0]);

		System.out.println(st[1]);

		String s = st[1].replace(".pdf", "");
		System.out.println(s);

		
		// Assignment no:02 
		//Count the vowels.....
		
		int count = 0; 
		for (int i = 0; i < str.length(); i++)
		{
			char ch=str.toLowerCase().charAt(i);
			if (ch == 'a' ||
				ch == 'e' || 
				ch == 'i' || 
				ch == 'o' ||
				ch == 'u') 
			   {
				count++;
			}
		}
		System.out.println("Total vowels in present string: "+count);

	}

}
