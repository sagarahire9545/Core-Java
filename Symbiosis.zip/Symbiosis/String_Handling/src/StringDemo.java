
public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="Java Programming";
		String str1="Python Programming";
		
		System.out.println(str.indexOf("m"));
		
		char ch=str.charAt(3); //store
		System.out.println(ch);
		
		int a=str.codePointAt(5);
		System.out.println(a);
		
		int b=str.codePointBefore(4);
		System.out.println(b);
		System.out.println("-------------");
		int cmp=str.compareTo(str1);
		System.out.println(cmp);

		String s1=str.concat(str1);
		System.out.println(s1);
	
		boolean bool=str.contains(s1);
		System.out.println(bool);
		
		boolean b1=str.contains("P");
		System.out.println(b1);
		
		boolean b2=str.equals(s1);
		System.out.println(b2);
		
		boolean b3=str1.endsWith("g");
		System.out.println(b3);
		
		boolean b4=str.startsWith("P");
		System.out.println(b4);
		
		
	}

}
