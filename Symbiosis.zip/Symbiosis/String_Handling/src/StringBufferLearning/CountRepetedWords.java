package StringBufferLearning;

public class CountRepetedWords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb=new StringBuilder("A simple paragraph is the first element taught in writing."
				+ " It is an independent entity, without any connection to any other topic, thought or idea."
				+ " It exists on its  own.");
		
		
		System.out.println(sb);
		
		int count = 0;
		String input="";              
		
		int index=sb.indexOf(input);
		while(index!=-1) {
			count++;
			sb.delete(0, index+input.length());
			index=sb.indexOf(input);
		}
		System.out.println("Counted Words: "+count);
	}
		

	}


