package StringBufferLearning;

//Thread safe,mutable sequence of characters

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer sb=new StringBuffer("Java");
		System.out.println(sb);
		
		sb.append(" Programming");
		System.out.println(sb);
		
		sb.append(" Language");
		System.out.println(sb);
		
		sb.insert(5," OOP");
		System.out.println(sb);
		
		sb.reverse();
		System.out.println(sb);
		
		sb.replace(5, 7, " OOP's");
		System.out.println(sb);
		sb.delete(5, 7);
				
	}

}
