import java.util.Iterator;

public class EverySecondCharacterUpperCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Hello Java Programmer";
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < str.length(); i++) {

			if (i % 2 != 0)
			{
				sb.append(str.toUpperCase().charAt(i));

			} else
			{
				sb.append(str.charAt(i));
			}
			System.out.println(sb);

		}

	}

}
