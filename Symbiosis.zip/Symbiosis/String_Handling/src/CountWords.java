
public class CountWords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = ("A simple paragraph is the first element taught in writing."
				+ " It is an independent entity, without any connection to any other topic, thought or idea."
				+ " It exists on its own.");

		// Assignment No:03
		// Count words given paragraph

		int count = 0;
		for (int i = 0; i < str.length(); i++) 
		{
			char ch=str.charAt(i);
			if (ch== ' ')
				count++;
		}
		System.out.println(count);
	}
	
	

}
