package method_overriding;

class SocialMedia
{
	 void status(String msg) {
		msg = "Social media..";
		System.out.println(msg);
	}
	
}
class Whatsapp extends SocialMedia{

	public void status(String msg) {
		msg = "Whatsapp";
		System.out.println(msg);
	}
}

class Instagram extends Whatsapp {

   public void status(String msg) {
		msg = "Instagram";
		System.out.println(msg);
	}
}

class Facebook extends Instagram {

	 public void status(String msg) {
		msg = "Facebook";
		System.out.println(msg);
	}
}

public class SocialMediaDemo {

	public static void main(String[] args) {
		
		SocialMedia sm=new Whatsapp();
		sm.status("");
		
		SocialMedia sm2=new Instagram();
		sm2.status("");
		
		SocialMedia sm3=new Facebook();
		sm3.status("");
		
		
	}

}
