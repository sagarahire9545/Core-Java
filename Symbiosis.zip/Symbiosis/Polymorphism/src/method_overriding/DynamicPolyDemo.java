package method_overriding;
class Bank
{
	public void ministatement() {
		System.out.println("Print last five transcation.");
	}
}

class Bank2 extends Bank
{
	@Override
	public void ministatement() {
		System.out.println("Print last ten transcation.");
	}
}

public class DynamicPolyDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Dynamic polymorphism   
		
		Bank bank=new Bank2();
		bank.ministatement();
	}

}
