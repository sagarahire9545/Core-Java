package method_overloading;

import java.util.Scanner;

class CalCul {
	public void math(int a, int b) {
		System.out.println("************ADDITON**************");
		System.out.println("First Number: " + a);
		System.out.println("Second Number: " + b);
		System.out.println("Addition of two numbers: " + (a + b));
		System.out.println("Completed....");
	}

	public void math(int a, int b, int c) {
		System.out.println("************SUBSTRACTION**************");
		System.out.println("First Number: " + a);
		System.out.println("Second Number: " + b);
		int sub = a - b;
		System.out.println("Substraction of two numbers: " + sub);
		System.out.println("Completed....");
	}

	public void math(int a, int b, int c, int d) {
		System.out.println("************MULTIPLICATION**************");
		System.out.println("First Number: " + a);
		System.out.println("Second Number: " + b);
		System.out.println("Third Number: " + c);
		System.out.println("Fourth Number: " + d);
		int mul = a * b * c * d;
		System.out.println("Multiplcation of two numbers: " + mul);
		System.out.println("Completed....");
	}

	public void math(float a, float b) {
		System.out.println("************DIVIDION**************");
		System.out.println("First Number: " + a);
		System.out.println("Second Number: " + b);
		float divide = a / b;
		System.out.println("Division of two numbers: " + divide);
		System.out.println("Completed....");
	}

}

public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CalCul cal = new CalCul();
		String str = " ";
		Scanner sc = new Scanner(System.in);

		do {
			System.out.println("-----------------WELCOME CALCULATOR------------------");
			System.out.println("1.ADDITONn");
			System.out.println("2.SUBSTRACTION");
			System.out.println("3.MULTIPLICATION");
			System.out.println("4.DIVIDION");
			System.out.println("----------------------");
			System.out.println("Enter your choice....");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Apply Addition operation...");
				System.out.println("Enter first number: ");
				int a = sc.nextInt();
				System.out.println("Rnter second number: ");
				int b = sc.nextInt();

				cal.math(a, b);
				break;

			case 2:
				System.out.println("Apply Substraction of three no.s ....");
				System.out.println("Enter first number: ");
				int a1 = sc.nextInt();
				System.out.println("Rnter second number: ");
				int b1 = sc.nextInt();
				System.out.println("Enter third number: ");
				int c = sc.nextInt();
				cal.math(a1, b1, c);
				break;

			case 3:
				System.out.println("Apply Multiplication operation...");
				System.out.println("Enter first number: ");
				int a2 = sc.nextInt();
				System.out.println("Rnter second number: ");
				int b2 = sc.nextInt();
				System.out.println("Enter third number: ");
				int c2 = sc.nextInt();
				System.out.println("Rnter fourth number: ");
				int d2 = sc.nextInt();
				cal.math(a2, b2, c2, d2);
				break;

			case 4:
				System.out.println("Apply Division operation...");
				System.out.println("Enter first number in float: ");
				int a3 = sc.nextInt();
				System.out.println("Rnter second number in float: ");
				int b3 = sc.nextInt();
				cal.math(a3, b3);
				break;

			default:
				System.out.println("Invalid input....");

			}
			System.out.println("Do you want to continue(y/Y) ");
			str = sc.next();

		} while (str.equalsIgnoreCase("y"));
		System.out.println("......Thanku.....");

	}

}
