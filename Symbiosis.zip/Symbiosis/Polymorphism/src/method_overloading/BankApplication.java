package method_overloading;

import java.util.Scanner;

class SBI {
	public void fundTransfer(int senderAcc, int reciverAcc, float amt) {

		System.out.println("Welcome to SBI net banking...\n please check your details");
		System.out.println("Sender Account Number: " + senderAcc);
		System.out.println("Reciver Account Number: " + reciverAcc);
		System.out.println("Transfer ammount: " + amt);
		System.out.println("Transfer succsssfully complted....!");

	}

	public void fundTransfer(int cheque, float amt, int reciverAcc) {

		System.out.println("Welcome to SBI net banking...\n please check your details");
		System.out.println("Cheque Number: " + cheque);
		System.out.println("Reciver Account Number: " + reciverAcc);
		System.out.println("Transfer ammount: " + amt);
		System.out.println("Transfer succsssfully complted....!");

	}

	public void fundTransfer(int ddnumber, float amt) {

		System.out.println("Welcome to SBI net banking...\n please check your details");
		System.out.println("Demand Draft Number: " + ddnumber);
		System.out.println("Transfer ammount: " + amt);
		System.out.println("Transfer succsssfully complted....!");

	}

	public void fundTransfer(String upiId, float amt) {

		System.out.println("Welcome to SBI net banking...\n please check your details");
		System.out.println("UPI ID: " + upiId);
		System.out.println("Transfer ammount: " + amt);
		System.out.println("Transfer succsssfully complted....!");

	}

}

public class BankApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "";
		Scanner sc = new Scanner(System.in);
		SBI sbi = new SBI();
		int senderAcc, receiverAcc, ddnumber, cheque;
		float amt;
		String upiId;

		do {
			System.out.println("!..................Welcome to SBI banking................!");
			System.out.println("press 1 for Net Banking");
			System.out.println("press 2 for DD Banking");
			System.out.println("press 3 for Cheque Banking");
			System.out.println("press 4 for Mobile Banking");
			System.out.println("------------------------");
			System.out.println("Please enter your choice");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:

				System.out.println("Please provide details..");
				System.out.println("Enter Sender Account Number: ");
				senderAcc = sc.nextInt();

				System.out.println("Enter Rceiverr Account Number: ");
				receiverAcc = sc.nextInt();

				System.out.println("Trnsfer Ammount: ");
				amt = sc.nextFloat();
				sbi.fundTransfer(senderAcc, receiverAcc, amt);

				break;

			case 2:
				System.out.println("Please provide details...");
				System.out.println("Enter DD Number: ");
				ddnumber = sc.nextInt();

				System.out.println("Trnsfer Ammount: ");
				amt = sc.nextFloat();

				sbi.fundTransfer(ddnumber, amt);
				break;

			case 3:
				System.out.println("Please provide details...");
				System.out.println("Enter Cheque Number: ");
				cheque = sc.nextInt();

				System.out.println("Trnsfer Ammount: ");
				amt = sc.nextFloat();

				System.out.println("Enter Rceiverr Account Number: ");
				receiverAcc = sc.nextInt();

				sbi.fundTransfer(cheque, amt, receiverAcc);
				break;

			case 4:
				System.out.println("Please provide details...");
				System.out.println("Enter UPI ID: ");
				upiId = sc.next();

				System.out.println("Trnsfer Ammount: ");
				amt = sc.nextFloat();

				sbi.fundTransfer(upiId, amt);
				break;
			default:
				System.out.println("Please enter your valid number this service not available.");

			}

			System.out.println("Do you want to continue(y/Y)....");
			str = sc.next();
		} while (str.equalsIgnoreCase("y"));
		System.out.println("Thank you Visited Again...!");

		/*
		 * SBI sb1=new SBI(); sb1.fundTransfer(1234, 9867, 10000.0f);
		 * 
		 * System.out.println("*******************"); sb1.fundTransfer(9527, 20000.0f,
		 * 9857);
		 * 
		 * System.out.println("*******************"); sb1.fundTransfer(952789,
		 * 80000.0f);
		 * 
		 * System.out.println("*******************"); sb1.fundTransfer("upi@1234",
		 * 50000.0f);
		 */

	}

}
